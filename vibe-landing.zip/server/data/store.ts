import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import type { Evento, Igreja, Recurso, Usuario, PerfilUsuario } from "@shared/api";
import { addHours, addDays } from "date-fns";

// Armazenamento em memória (pode ser substituído por DB futuramente)
export const db = {
  usuarios: [] as Usuario[],
  igrejas: [] as Igreja[],
  recursos: [] as Recurso[],
  eventos: [] as Evento[],
};

export function semearDados() {
  if (db.usuarios.length > 0) return;

  const igrejaCentral: Igreja = {
    id: randomUUID(),
    nome: "Igreja Central",
    endereco: "Av. Principal, 100",
    codigoCor: "#22c55e",
  };
  const igrejaJardim: Igreja = {
    id: randomUUID(),
    nome: "Igreja Jardim",
    endereco: "Rua das Flores, 200",
    codigoCor: "#3b82f6",
  };
  db.igrejas.push(igrejaCentral, igrejaJardim);

  const projetor: Recurso = { id: randomUUID(), nome: "Projetor Multimidia", tipo: "equipamento", estaDisponivel: true };
  const salaPrincipal: Recurso = { id: randomUUID(), nome: "Salao Principal", tipo: "espaco", estaDisponivel: true };
  const salaJuventude: Recurso = { id: randomUUID(), nome: "Sala Juventude", tipo: "espaco", estaDisponivel: true };
  db.recursos.push(projetor, salaPrincipal, salaJuventude);

  const senhaAdmin = bcrypt.hashSync("admin123", 10);
  const senhaLider = bcrypt.hashSync("lider123", 10);
  const senhaMembro = bcrypt.hashSync("membro123", 10);

  const admin: Usuario = {
    id: randomUUID(),
    nome: "Administrador",
    email: "admin@agendaviva.app",
    senhaHash: senhaAdmin,
    perfil: "administrador",
    igrejaId: null,
    dataNascimento: "1980-01-15",
  };
  const lider: Usuario = {
    id: randomUUID(),
    nome: "Líder Central",
    email: "lider@central.app",
    senhaHash: senhaLider,
    perfil: "lider",
    igrejaId: igrejaCentral.id,
    dataNascimento: "1990-03-10",
  };
  const membro: Usuario = {
    id: randomUUID(),
    nome: "Membro Jardim",
    email: "membro@jardim.app",
    senhaHash: senhaMembro,
    perfil: "membro",
    igrejaId: igrejaJardim.id,
    dataNascimento: "1995-09-09",
  };
  db.usuarios.push(admin, lider, membro);

  const agora = new Date();
  const evento1: Evento = {
    id: randomUUID(),
    titulo: "Culto de Domingo",
    descricao: "Celebração principal",
    dataHoraInicio: new Date(agora.getFullYear(), agora.getMonth(), 15, 9, 0, 0).toISOString(),
    dataHoraFim: new Date(agora.getFullYear(), agora.getMonth(), 15, 11, 0, 0).toISOString(),
    criadoPor: lider.id,
    igrejaId: igrejaCentral.id,
    recursoId: salaPrincipal.id,
    diaInteiro: false,
  };
  const evento2: Evento = {
    id: randomUUID(),
    titulo: "Ensaio Louvor",
    descricao: "Preparação para o culto",
    dataHoraInicio: addDays(addHours(agora, 24), 1).toISOString(),
    dataHoraFim: addDays(addHours(agora, 26), 1).toISOString(),
    criadoPor: lider.id,
    igrejaId: igrejaCentral.id,
    recursoId: projetor.id,
    diaInteiro: false,
  };
  db.eventos.push(evento1, evento2);
}

export function sobrepoeIntervalo(aInicio: Date, aFim: Date, bInicio: Date, bFim: Date) {
  return aInicio < bFim && aFim > bInicio;
}

export function ehConflito(evento: Evento, outro: Evento) {
  if (evento.igrejaId !== outro.igrejaId) return false;
  const mesmoRecursoOuEspacoPrincipal = (evento.recursoId ?? "__principal__") === (outro.recursoId ?? "__principal__");
  if (!mesmoRecursoOuEspacoPrincipal) return false;
  return sobrepoeIntervalo(new Date(evento.dataHoraInicio), new Date(evento.dataHoraFim), new Date(outro.dataHoraInicio), new Date(outro.dataHoraFim));
}

export function gerarId() {
  return randomUUID();
}
