import { useEffect, useMemo, useRef, useState } from "react";
import { Calendar, dateFnsLocalizer, Views } from "react-big-calendar";
import { format, parse, startOfWeek, getDay, startOfMonth, endOfMonth, addMonths, startOfDay, endOfDay } from "date-fns";
import ptBR from "date-fns/locale/pt-BR";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { api } from "@/lib/api";
import type { Evento, Igreja } from "@shared/api";
import { useAuth } from "@/hooks/use-auth";
import { EventoModal } from "./EventoModal";
import { IgrejaModal } from "./IgrejaModal";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const locales = { "pt-BR": ptBR };
const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek: () => startOfWeek(new Date(), { weekStartsOn: 0 }),
  getDay,
  locales,
});

export default function CalendarioPrincipal() {
  const { usuario } = useAuth();
  const [eventos, setEventos] = useState<Evento[]>([]);
  const [igrejas, setIgrejas] = useState<Igreja[]>([]);
  const [modalAberto, setModalAberto] = useState(false);
  const [eventoSelecionado, setEventoSelecionado] = useState<Evento | null>(null);
  const [dataInicialModal, setDataInicialModal] = useState<Date | null>(null);
  const [intervalo, setIntervalo] = useState<{ inicio: Date; fim: Date }>(() => {
    const hoje = new Date();
    return { inicio: startOfMonth(hoje), fim: endOfMonth(hoje) } as any;
  });
  const [modalIgreja, setModalIgreja] = useState(false);
  const [modo, setModo] = useState<"mes" | "anual">("mes");
  const [anoVisao, setAnoVisao] = useState<number>(new Date().getFullYear());

  const calendarioRef = useRef<HTMLDivElement>(null);

  useEffect(() => { api.listarIgrejas().then(setIgrejas); }, []);

  async function carregarEventos(i?: Date, f?: Date) {
    const ini = (i ?? intervalo.inicio).toISOString();
    const fim = (f ?? intervalo.fim).toISOString();
    const dados = await api.listarEventos(ini, fim);
    setEventos(dados);
  }

  useEffect(() => { carregarEventos(); }, [intervalo.inicio.getTime(), intervalo.fim.getTime()]);

  const eventosRbc = useMemo(() => eventos.map((e) => ({
    id: e.id,
    title: e.titulo,
    start: new Date(e.dataHoraInicio),
    end: new Date(e.dataHoraFim),
    allDay: Boolean(e.diaInteiro),
    resource: e,
  })), [eventos]);

  const maxEventosEmUmDia = useMemo(() => {
    const mapa = new Map<string, number>();
    for (const e of eventos) {
      const d = startOfDay(new Date(e.dataHoraInicio));
      const chave = d.toISOString().slice(0, 10);
      mapa.set(chave, (mapa.get(chave) || 0) + 1);
    }
    let max = 0; mapa.forEach((v) => { if (v > max) max = v; });
    return max;
  }, [eventos]);

  const estilosEvento = (event: any) => {
    const ev: Evento = event.resource;
    const igreja = igrejas.find((i) => i.id === ev.igrejaId);
    const cor = igreja?.codigoCor || "#16a34a";
    return { style: { backgroundColor: cor, backgroundImage: "linear-gradient(to bottom, rgba(255,255,255,.18), rgba(0,0,0,.06))", borderRadius: 12, color: "white", border: "1px solid rgba(255,255,255,.35)", boxShadow: "0 8px 24px rgba(0,0,0,.15)" } };
  };

  function abrirCriacaoNaData(date: Date) {
    setEventoSelecionado(null);
    setDataInicialModal(date);
    setModalAberto(true);
  }

  function abrirEdicao(ev: any) {
    setEventoSelecionado(ev.resource as Evento);
    setDataInicialModal(null);
    setModalAberto(true);
  }

  async function aoSalvar() {
    await carregarEventos();
  }

  function hexToRgb(hex: string) {
    const h = hex.replace('#','');
    const bigint = parseInt(h.length === 3 ? h.split('').map((c)=>c+c).join('') : h, 16);
    const r = (bigint >> 16) & 255, g = (bigint >> 8) & 255, b = bigint & 255;
    return { r, g, b };
  }

  async function exportarCalendarioMensal() {
    const pdf = new jsPDF("l", "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margem = 12;

    // Título
    pdf.setFontSize(18);
    const titulo = `Calendário • ${format(intervalo.inicio, "MMMM 'de' yyyy", { locale: ptBR })}`;
    pdf.text(titulo, margem, 18);

    // Área do calendário
    const headerH = 10;
    const legendaH = 36; // espaço para legenda e resumo
    const gridH = pageHeight - margem - legendaH - 24; // 24 espaço pós título
    const gridTop = 24;
    const gridLeft = margem;
    const colW = (pageWidth - margem * 2) / 7;
    const rowH = gridH / 6;

    // Cabeçalho dos dias
    pdf.setFillColor(245, 247, 250);
    pdf.setDrawColor(224);
    const dias = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    for (let c = 0; c < 7; c++) {
      const x = gridLeft + c * colW;
      pdf.rect(x, gridTop, colW, headerH, 'F');
      pdf.setFontSize(11);
      pdf.text(dias[c], x + 2, gridTop + 7);
    }

    // Datas
    const inicioMes = startOfMonth(intervalo.inicio);
    const inicioGrade = startOfWeek(inicioMes, { weekStartsOn: 0 });
    const diasNoGrid = 42; // 6x7

    pdf.setFontSize(9);

    for (let i = 0; i < diasNoGrid; i++) {
      const data = new Date(inicioGrade.getTime());
      data.setDate(inicioGrade.getDate() + i);
      const r = Math.floor(i / 7);
      const c = i % 7;
      const x = gridLeft + c * colW;
      const y = gridTop + headerH + r * rowH;

      // célula
      pdf.setDrawColor(230);
      pdf.rect(x, y, colW, rowH);

      const inMonth = data.getMonth() === inicioMes.getMonth();
      pdf.setTextColor(inMonth ? 20 : 160);
      pdf.text(String(data.getDate()).padStart(2, '0'), x + colW - 6, y + 5, { align: 'right' as const });

      // Eventos do dia
      const iniDia = new Date(data); iniDia.setHours(0,0,0,0);
      const fimDia = new Date(data); fimDia.setHours(23,59,59,999);
      const doDia = eventos.filter((e) => new Date(e.dataHoraInicio) < fimDia && new Date(e.dataHoraFim) > iniDia);
      let ey = y + 10;
      pdf.setFontSize(7.5);
      for (const ev of doDia.slice(0, 4)) { // máx 4 por célula
        const cor = igrejas.find((i)=> i.id === ev.igrejaId)?.codigoCor || '#16a34a';
        const { r: rr, g, b } = hexToRgb(cor);
        pdf.setFillColor(rr, g, b);
        pdf.circle(x + 3.5, ey - 2.2, 1.5, 'F');
        const hora = format(new Date(ev.dataHoraInicio), 'HH:mm');
        const txt = `${hora} ${ev.titulo}`;
        const lines = pdf.splitTextToSize(txt, colW - 10);
        pdf.setTextColor(40);
        pdf.text(lines, x + 7, ey);
        ey += Math.min(lines.length, 2) * 4;
        if (ey > y + rowH - 4) break;
      }
      if (doDia.length > 4) {
        pdf.setTextColor(120);
        pdf.text(`+${doDia.length - 4} mais`, x + 7, y + rowH - 3);
      }
    }

    // Legenda
    let legendY = gridTop + headerH + 6 * rowH + 8;
    pdf.setFontSize(12);
    pdf.setTextColor(20);
    pdf.text('Legenda', margem, legendY);
    legendY += 6;
    pdf.setFontSize(10);
    for (const ig of igrejas.slice(0, 8)) {
      const { r, g, b } = hexToRgb(ig.codigoCor || '#16a34a');
      pdf.setFillColor(r, g, b);
      pdf.rect(margem, legendY - 4, 4, 4, 'F');
      pdf.setTextColor(50);
      pdf.text(ig.nome, margem + 8, legendY);
      legendY += 6;
    }

    // Resumo
    let y = legendY + 4;
    pdf.setFontSize(12);
    pdf.setTextColor(20);
    pdf.text('Resumo do mês', margem, y);
    y += 6;
    pdf.setFontSize(10);
    const ordenados = [...eventos].sort((a,b)=> new Date(a.dataHoraInicio).getTime()-new Date(b.dataHoraInicio).getTime());
    for (const ev of ordenados) {
      const dataTxt = format(new Date(ev.dataHoraInicio), 'dd/MM HH:mm');
      const linha = `${dataTxt} – ${ev.titulo}${ev.descricao ? `: ${ev.descricao}` : ''}`;
      const linhas = pdf.splitTextToSize(linha, pageWidth - margem*2);
      if (y + linhas.length * 5 > pageHeight - margem) { pdf.addPage(); y = margem; }
      pdf.setTextColor(60);
      pdf.text(linhas, margem, y);
      y += linhas.length * 5 + 2;
    }

    pdf.save('calendario-mensal.pdf');
  }

  async function exportarResumoAnual() {
    const ano = new Date().getFullYear();
    const todos: Evento[] = [];
    for (let m = 0; m < 12; m++) {
      const ini = new Date(ano, m, 1);
      const fim = endOfMonth(ini);
      const parte = await api.listarEventos(ini.toISOString(), fim.toISOString());
      todos.push(...parte);
    }
    todos.sort((a, b) => new Date(a.dataHoraInicio).getTime() - new Date(b.dataHoraInicio).getTime());
    const pdf = new jsPDF("p", "mm", "a4");
    pdf.setFontSize(18);
    pdf.text(`Resumo Anual ${ano}`, 14, 16);
    pdf.setFontSize(11);
    let y = 26;
    for (const e of todos) {
      const data = format(new Date(e.dataHoraInicio), "dd/MM/yyyy HH:mm");
      const linha = `${data} – ${e.titulo}${e.descricao ? `: ${e.descricao}` : ""}`;
      const linhas = pdf.splitTextToSize(linha, 180);
      if (y + linhas.length * 6 > 280) { pdf.addPage(); y = 20; }
      pdf.text(linhas, 14, y);
      y += linhas.length * 6;
      pdf.setDrawColor(230); pdf.line(14, y - 4, 200, y - 4);
    }
    pdf.save("resumo-anual.pdf");
  }

  const titulo = modo === "mes" ? format(intervalo.inicio, "MMMM 'de' yyyy", { locale: ptBR }) : `Ano ${anoVisao}`;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Calendário</h1>
          <p className="text-sm text-muted-foreground">Crie e gerencie atividades da comunidade</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={exportarCalendarioMensal} className="btn-premium bg-gradient-to-r from-teal-500 to-sky-500">Exportar Calendário do Mês</button>
          <button onClick={exportarResumoAnual} className="btn-premium bg-gradient-to-r from-sky-500 to-violet-500">Exportar Resumo Anual</button>
          {(usuario?.perfil === "administrador") && (
            <button onClick={() => setModalIgreja(true)} className="btn-premium">Nova Igreja</button>
          )}
          {(usuario?.perfil === "administrador" || usuario?.perfil === "lider") && (
            <button onClick={() => abrirCriacaoNaData(new Date())} className="btn-premium">Adicionar Atividade</button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-3">
          <div ref={calendarioRef} className="gradient-border rounded-2xl bg-card/90 p-3 shadow-xl ring-1 ring-black/5 backdrop-blur-sm overflow-hidden">
            <div className="flex items-center justify-between px-2 pb-3">
              <div className="flex items-center gap-2" />
              <h2 className="text-lg font-semibold capitalize tracking-tight">{titulo}</h2>
              <div className="flex items-center gap-2">
                <button onClick={() => setModo('mes')} className={`px-3 py-1.5 rounded-md text-sm transition ${modo==='mes' ? 'bg-emerald-600 text-white shadow' : 'bg-secondary hover:bg-secondary/80'}`}>Mês</button>
                <button onClick={() => setModo('anual')} className={`px-3 py-1.5 rounded-md text-sm transition ${modo==='anual' ? 'bg-emerald-600 text-white shadow' : 'bg-secondary hover:bg-secondary/80'}`}>Anual</button>
              </div>
            </div>
            {modo === 'mes' ? (
              <Calendar
                localizer={localizer}
                culture="pt-BR"
                events={eventosRbc}
                startAccessor="start"
                endAccessor="end"
                style={{ minHeight: 680 + Math.max(0, maxEventosEmUmDia - 2) * 48 }}
                views={[Views.MONTH]}
                messages={{ month: "Mês", week: "Semana", day: "Dia", today: "Hoje", previous: "Anterior", next: "Próximo", noEventsInRange: "Sem eventos" }}
                onNavigate={(date) => {
                  const ini = startOfMonth(date);
                  const fim = endOfMonth(date);
                  setIntervalo({ inicio: ini, fim });
                }}
                selectable
                onSelectSlot={(slot) => abrirCriacaoNaData(slot.start)}
                onSelectEvent={abrirEdicao}
                eventPropGetter={estilosEvento}
                dayPropGetter={() => ({ className: "agv-day" })}
                showAllEvents
                components={{
                  event: ({ event }: any) => <CustomEvent ev={event.resource as any} igrejas={igrejas} />,
                }}
              />
            ) : (
              <CalendarioAnual ano={anoVisao} eventos={eventos} igrejas={igrejas} onClickDia={abrirCriacaoNaData} />
            )}
          </div>
        </div>
        <div className="space-y-4">
          <AniversariantesWidget />
          <LegendaIgrejas igrejas={igrejas} />
        </div>
      </div>

      <EventoModal aberto={modalAberto} onFechar={() => setModalAberto(false)} evento={eventoSelecionado} dataInicial={dataInicialModal ?? undefined} onSalvo={aoSalvar} />
      <IgrejaModal aberto={modalIgreja} onFechar={() => setModalIgreja(false)} onCriada={() => api.listarIgrejas().then(setIgrejas)} />
    </div>
  );
}


function CustomEvent({ ev, igrejas }: { ev: Evento; igrejas: Igreja[] }) {
  const igreja = igrejas.find((i) => i.id === ev.igrejaId);
  const cor = igreja?.codigoCor || '#16a34a';
  const horaIni = format(new Date(ev.dataHoraInicio), 'HH:mm');
  const horaFim = format(new Date(ev.dataHoraFim), 'HH:mm');
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div className="relative group cursor-pointer">
          <div className="flex items-start gap-1.5 leading-tight transition-transform duration-200 group-hover:scale-[1.02]">
            <span className="mt-1 inline-block h-2 w-2 rounded-full" style={{ backgroundColor: cor }} />
            <div className="text-[11px]">
              <div className="font-semibold truncate pr-2">{ev.titulo}</div>
              <div className="opacity-90">{horaIni}–{horaFim}</div>
            </div>
          </div>
        </div>
      </TooltipTrigger>
      <TooltipContent className="max-w-xs">
        <div className="text-sm font-medium mb-1" style={{ color: cor }}>{ev.titulo}</div>
        <div className="text-xs text-muted-foreground mb-1">{horaIni}–{horaFim}{ev.diaInteiro ? ' • dia inteiro' : ''}</div>
        {igreja?.nome && <div className="text-xs">Igreja: {igreja.nome}</div>}
        {ev.descricao && <div className="mt-1 text-xs leading-snug">{ev.descricao}</div>}
      </TooltipContent>
    </Tooltip>
  );
}

function AniversariantesWidget() {
  const [lista, setLista] = useState<{ id: string; nome: string; dataNascimento: string }[]>([]);
  useEffect(() => { api.aniversariantes().then(setLista); }, []);
  return (
    <div className="rounded-2xl border border-border bg-card/90 p-4 shadow-lg ring-1 ring-black/5">
      <h3 className="font-medium mb-2">Aniversariantes do mês</h3>
      {lista.length === 0 ? (
        <p className="text-sm text-muted-foreground">Nenhum aniversariante hoje.</p>
      ) : (
        <ul className="space-y-1 text-sm">
          {lista.map((a) => (<li key={a.id}>🎉 {a.nome}</li>))}
        </ul>
      )}
    </div>
  );
}

function LegendaIgrejas({ igrejas }: { igrejas: Igreja[] }) {
  return (
    <div className="rounded-2xl border border-border bg-card/90 p-4 shadow-lg ring-1 ring-black/5">
      <h3 className="font-medium mb-2">Legenda</h3>
      <ul className="space-y-2 text-sm">
        {igrejas.map((i) => (
          <li key={i.id} className="flex items-center gap-2">
            <span className="inline-block h-3 w-3 rounded" style={{ backgroundColor: i.codigoCor || "#16a34a" }} />
            <span>{i.nome}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CalendarioAnual({ ano, eventos, igrejas, onClickDia }: { ano: number; eventos: Evento[]; igrejas: Igreja[]; onClickDia: (d: Date) => void }) {
  const meses = Array.from({ length: 12 }, (_, i) => i);
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
      {meses.map((m) => (
        <MiniMes
          key={m}
          ano={ano}
          mes={m}
          eventos={eventos}
          igrejas={igrejas}
          onClickDia={onClickDia}
        />
      ))}
    </div>
  );
}

function MiniMes({ ano, mes, eventos, igrejas, onClickDia }: { ano: number; mes: number; eventos: Evento[]; igrejas: Igreja[]; onClickDia: (d: Date) => void }) {
  const primeiro = startOfMonth(new Date(ano, mes, 1));
  const inicio = startOfWeek(primeiro, { weekStartsOn: 0 });
  const dias: Date[] = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(inicio); d.setDate(inicio.getDate() + i); dias.push(d);
  }
  const titulo = format(primeiro, "MMMM", { locale: ptBR });
  const nomes = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
  return (
    <div className="rounded-xl border border-border bg-card/80 p-3 shadow ring-1 ring-black/5">
      <div className="flex items-center justify-between mb-2">
        <div className="font-medium capitalize">{titulo}</div>
      </div>
      <div className="grid grid-cols-7 text-[11px] text-muted-foreground mb-1">
        {nomes.map((n) => (<div key={n} className="text-center">{n}</div>))}
      </div>
      <div className="grid grid-cols-7 gap-px">
        {dias.map((d, i) => {
          const inMonth = d.getMonth() === mes;
          const doDia = eventos.filter((e) => new Date(e.dataHoraInicio) < endOfDay(d) && new Date(e.dataHoraFim) > startOfDay(d));
          return (
            <Tooltip key={i}>
              <TooltipTrigger asChild>
                <button onClick={() => onClickDia(d)} className={`relative h-16 rounded-md p-1 text-left transition ${inMonth ? 'bg-background hover:bg-muted/60' : 'bg-muted/40 text-muted-foreground'}`}>
                  <span className="absolute top-1 right-1 text-[10px] opacity-70">{d.getDate()}</span>
                  <div className="mt-4 space-y-0.5 overflow-hidden">
                    {doDia.slice(0,3).map((ev) => {
                      const cor = igrejas.find((i)=> i.id === ev.igrejaId)?.codigoCor || '#16a34a';
                      return <div key={ev.id} className="h-1.5 rounded-full" style={{ backgroundColor: cor }} />;
                    })}
                    {doDia.length > 3 && <div className="text-[10px] opacity-70">+{doDia.length-3}</div>}
                  </div>
                </button>
              </TooltipTrigger>
              {doDia.length > 0 && (
                <TooltipContent className="max-w-xs">
                  <div className="text-xs font-medium mb-1">{format(d,'dd/MM')}</div>
                  <ul className="text-xs space-y-1">
                    {doDia.map((ev) => (
                      <li key={ev.id}>
                        <span className="inline-block h-2 w-2 rounded-full mr-1 align-middle" style={{ backgroundColor: igrejas.find((i)=> i.id === ev.igrejaId)?.codigoCor || '#16a34a' }} />
                        {format(new Date(ev.dataHoraInicio),'HH:mm')} – {ev.titulo}
                      </li>
                    ))}
                  </ul>
                </TooltipContent>
              )}
            </Tooltip>
          );
        })}
      </div>
    </div>
  );
}
