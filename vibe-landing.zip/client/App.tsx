import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Admin from "./pages/Admin";
import { ProvedorAuth, useAuth } from "@/hooks/use-auth";

const queryClient = new QueryClient();

import { motion } from "framer-motion";
function Cabecalho() {
  const { usuario, sair } = useAuth();
  const loc = useLocation();
  const ativo = (p: string) => (loc.pathname === p ? "text-primary" : "text-foreground/80 hover:text-foreground");
  function alternarTema() {
    const el = document.documentElement;
    el.classList.toggle("dark");
  }
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/60 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between gap-[233px]">
        <a href="https://5c6e9666b56f47129f5e899c904e651d-236c7abd5ee548cd91ea84832.fly.dev/" className="group flex items-center gap-3">
          <motion.div className="relative h-7 w-7" initial={{ rotate: -10, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} transition={{ type: 'spring', stiffness: 120, damping: 12 }}>
            <span className="absolute inset-0 rounded-lg bg-gradient-to-br from-emerald-400 to-teal-600 blur-sm opacity-60 group-hover:opacity-90 transition" />
            <span className="relative block h-full w-full rounded-lg bg-emerald-600" />
          </motion.div>
          <motion.span className="font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-emerald-600 to-teal-500" initial={{ y: -8, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .05, duration: .4 }}>
            Agenda Viva
          </motion.span>
        </a>
        <nav className="hidden sm:flex items-center gap-6 text-sm">
          <Link to="/" className={ativo("/")}>Calendário</Link>
        </nav>
        <div className="flex items-center gap-3 text-sm">
          <button onClick={alternarTema} title="Alternar tema" className="rounded-md px-2 py-1.5 bg-secondary/70 hover:bg-secondary text-foreground/80">Tema</button>
          {usuario ? (
            <>
              <span className="hidden md:inline text-foreground/70">{usuario.nome} • </span>
              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: .98 }} onClick={sair} className="px-3 py-1.5 rounded-md bg-gradient-to-r from-emerald-600 to-teal-500 text-white shadow hover:shadow-md">Sair</motion.button>
            </>
          ) : (
            <Link to="/login" className={ativo("/login")}>Entrar</Link>
          )}
        </div>
      </div>
    </header>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen text-foreground animated-bg">
      <Cabecalho />
      <main className="container py-8">
        <div className="gradient-border rounded-3xl bg-card/80 backdrop-blur-xl p-4 sm:p-6 shadow-[0_10px_40px_-15px_rgba(0,0,0,0.35)] ring-1 ring-black/5">
          {children}
        </div>
      </main>
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <ProvedorAuth>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout><Index /></Layout>} />
            <Route path="/login" element={<Layout><Login /></Layout>} />
            <Route path="/admin" element={<Layout><Admin /></Layout>} />
            <Route path="*" element={<Layout><NotFound /></Layout>} />
          </Routes>
        </BrowserRouter>
      </ProvedorAuth>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
