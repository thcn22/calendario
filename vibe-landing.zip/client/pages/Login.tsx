import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/use-auth";

export default function Login() {
  const { entrar } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro(null);
    setCarregando(true);
    try {
      await entrar(email, senha);
      nav("/");
    } catch (err: any) {
      setErro(err.message || "Falha no login");
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="mx-auto max-w-md bg-card border border-border rounded-xl p-6 shadow-sm">
      <h1 className="text-xl font-semibold mb-4">Entrar</h1>
      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="block text-sm mb-1" htmlFor="email">Email</label>
          <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full rounded-md border border-input bg-background px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div>
          <label className="block text-sm mb-1" htmlFor="senha">Senha</label>
          <input id="senha" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required className="w-full rounded-md border border-input bg-background px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        {erro && <p className="text-destructive text-sm">{erro}</p>}
        <button disabled={carregando} className="w-full rounded-md bg-primary text-primary-foreground py-2 hover:opacity-90 disabled:opacity-50">{carregando ? "Entrando..." : "Entrar"}</button>
      </form>
      <div className="mt-3 text-xs text-muted-foreground">
        Dicas para testes: admin@agendaviva.app / admin123 | lider@central.app / lider123 | membro@jardim.app / membro123
      </div>
    </div>
  );
}
