import CalendarioPrincipal from "@/components/agenda/CalendarioPrincipal";
import { useAuth } from "@/hooks/use-auth";

export default function Index() {
  const { estaAutenticado } = useAuth();
  return (
    <div className="space-y-4">
      {!estaAutenticado && (
        <div className="rounded-lg border border-amber-300 bg-amber-50 text-amber-900 p-3 text-sm">
          Você está acessando como visitante. Entre para criar e gerenciar atividades.
        </div>
      )}
      <CalendarioPrincipal />
    </div>
  );
}
