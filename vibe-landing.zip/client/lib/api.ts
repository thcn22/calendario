import type { AtualizarEventoDTO, CriarEventoDTO, Evento, Igreja, LoginRequisicao, LoginResposta, Recurso, Usuario, AniversarianteDoDia } from "@shared/api";

const BASE = ""; // mesmo host

function obterToken() {
  return localStorage.getItem("agenda_viva_token");
}

async function req<T>(url: string, init?: RequestInit): Promise<T> {
  const headers: HeadersInit = { "Content-Type": "application/json", ...(init?.headers || {}) };
  const token = obterToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const resp = await fetch(`${BASE}${url}`, { ...init, headers });
  if (!resp.ok) {
    const txt = await resp.text();
    let msg = txt;
    try { msg = JSON.parse(txt)?.erro || msg; } catch {}
    throw new Error(msg || resp.statusText);
  }
  return resp.json();
}

export const api = {
  login: (dados: LoginRequisicao) => req<LoginResposta>("/api/autenticacao/login", { method: "POST", body: JSON.stringify(dados) }),

  listarIgrejas: () => req<Igreja[]>("/api/igrejas"),
  criarIgreja: (dados: { nome: string; endereco?: string | null; codigoCor?: string | null }) => req<Igreja>("/api/igrejas", { method: "POST", body: JSON.stringify(dados) }),
  listarRecursos: () => req<Recurso[]>("/api/recursos"),

  listarEventos: (inicio?: string, fim?: string) => {
    const params = inicio && fim ? `?inicio=${encodeURIComponent(inicio)}&fim=${encodeURIComponent(fim)}` : "";
    return req<Evento[]>(`/api/eventos${params}`);
  },
  criarEvento: (dados: CriarEventoDTO) => req<Evento>("/api/eventos", { method: "POST", body: JSON.stringify(dados) }),
  atualizarEvento: (id: string, dados: AtualizarEventoDTO) => req<Evento>(`/api/eventos/${id}`, { method: "PUT", body: JSON.stringify(dados) }),
  removerEvento: (id: string) => req<void>(`/api/eventos/${id}`, { method: "DELETE" }),

  aniversariantes: (dia?: number, mes?: number) => req<AniversarianteDoDia[]>(`/api/usuarios/aniversariantes${dia && mes ? `?dia=${dia}&mes=${mes}` : ""}`),
};
